/**
 * A utility script that enables clipboard copying of URLs when elements with
 * the js-copy-link class are clicked.
 *
 * @author Your Name
 * @version 1.0.0
 * @license MIT
 */

/**
 * Initialize click handlers for all elements with the js-copy-link class
 * to copy their href value to the clipboard when clicked.
 *
 * @returns {void}
 */
document.addEventListener('DOMContentLoaded', function () {
  // Find all links with the js-copy-link class
  const copyLinks = document.querySelectorAll('.js-copy-link');

  // Add click event listener to each link
  copyLinks.forEach(link => {
    link.addEventListener('click', function(event) {
      handleCopyLinkClick.call(this, event);
    });
  });

  // Create a reusable notification element and add it to the body
  const notification = document.createElement('div');
  notification.className = 'copy-notification';
  document.body.appendChild(notification);

  // Expose the notification element globally for our functions to use
  window.copyNotification = notification;
});

/**
 * Event handler for copy link clicks
 * Prevents default link behavior and copies the URL to clipboard
 *
 * @param {Event} event - The click event object
 * @returns {void}
 */
function handleCopyLinkClick(event) {
  // Prevent default link behavior
  event.preventDefault();

  // Get the URL from href attribute
  const url = this.getAttribute('href');

  // Get the position of the clicked link
  const linkRect = this.getBoundingClientRect();

  // Copy the URL to clipboard and show notification
  copyUrlToClipboard(url, this);
}

/**
 * Copies a URL to the clipboard and shows temporary notification
 *
 * @param {string} url - The URL to copy to clipboard
 * @param {HTMLElement} linkElement - The element that was clicked
 * @returns {void}
 */
function copyUrlToClipboard(url, linkElement) {
  navigator.clipboard.writeText(url)
    .then(() => {
      // Show notification under the link
      showTemporaryNotification('Link copied to clipboard!', linkElement);
    })
    .catch(err => {
      console.error('Failed to copy: ', err);
      showTemporaryNotification('Failed to copy link', linkElement);
    });
}

/**
 * Shows a temporary notification under the specified element
 *
 * @param {string} message - Message to display in the notification
 * @param {HTMLElement} element - Element to position the notification under
 * @param {number} [duration=3000] - Time in milliseconds before notification disappears
 * @returns {void}
 */
function showTemporaryNotification(message, element, duration = 3000) {
  const notification = window.copyNotification;
  const elementRect = element.getBoundingClientRect();

  // Position the notification centered under the element
  const notificationWidth = notification.offsetWidth || 150; // Estimate if not yet rendered
  notification.style.left = `${elementRect.left + (elementRect.width/2) - (notificationWidth/2) + window.scrollX}px`;
  notification.style.top = `${elementRect.bottom + window.scrollY + 5}px`; // 5px gap

  // Set the message
  notification.textContent = message;

  // Show the notification
  notification.style.display = 'block';

  // Hide the notification after the specified duration
  setTimeout(() => {
    notification.style.display = 'none';
  }, duration);
}
