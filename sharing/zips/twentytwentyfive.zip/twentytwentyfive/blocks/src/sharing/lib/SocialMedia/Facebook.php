<?php

namespace ValveBlock\Sharing\SocialMedia;

/**
 * Facebook sharing link.
 *
 * @package ValveBlock
 * @subpackage Sharing
 */

class Facebook {

    /**
     * Get Facebook sharing link.
     *
     * @param string $current_link The link of current page
     * @return string Link to share current page.
     */
    public static function get_sharing_link( $current_link ) {
        $facebook_sharing_link = '';

				if ( $current_link ) {
					$facebook_sharing_link = 'https://www.facebook.com/sharer.php?u=' . $current_link ;
				}

        return $facebook_sharing_link;
    }
}
