<?php

namespace ValveBlock\Sharing\SocialMedia;

/**
 * X sharing link.
 *
 * @package ValveBlock
 * @subpackage Sharing
 */

class X {

    /**
     * Get X sharing link.
     *
     * @param string $current_link The link of current page
     * @return string Link to share current page.
     */
    public static function get_sharing_link( $current_link ) {
        $x_sharing_link = '';

				if ( $current_link ) {
					$x_sharing_link = 'https://twitter.com/intent/tweet?url=' . $current_link ;
				}

        return $x_sharing_link;
    }
}
