<?php

namespace ValveBlock\Sharing\SocialMedia;

/**
 * LinkedIn sharing link.
 *
 * @package ValveBlock
 * @subpackage Sharing
 */

class LinkedIn {

    /**
     * Get LinkedIn sharing link.
     *
     * @param string $current_link The link of current page
     * @return string Link to share current page.
     */
    public static function get_sharing_link( $current_link ) {
        $linkedin_sharing_link = '';

				if ( $current_link ) {
					$linkedin_sharing_link = 'https://www.linkedin.com/sharing/share-offsite/?url=' . $current_link ;
				}

        return $linkedin_sharing_link;
    }
}
