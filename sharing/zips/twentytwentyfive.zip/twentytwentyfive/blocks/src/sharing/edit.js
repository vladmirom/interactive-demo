/**
 * WordPress dependencies
 */
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';

/**
 * Internal dependencies
 */
import {
  SharingMethodsControl,
  ColorControls,
  StylingControls,
  SharingIcons
} from './scripts/scripts';

import './editor.scss';

/**
 * Block Edit component
 *
 * @param {Object} props Block props
 * @return {WPElement} Element to render
 */
export default function Edit({ attributes, setAttributes }) {
  return (
    <>
      {/* Sidebar Controls */}
      <InspectorControls>
        <SharingMethodsControl
          attributes={attributes}
          setAttributes={setAttributes}
        />
        <ColorControls
          attributes={attributes}
          setAttributes={setAttributes}
        />
        <StylingControls
          attributes={attributes}
          setAttributes={setAttributes}
        />
      </InspectorControls>

      {/* Block Display */}
      <div
        {...useBlockProps({
          // Disabling hover on the whole block to enable it for specific block elements
          onMouseEnter: undefined,
          onMouseLeave: undefined,
        })}
      >
        <SharingIcons
          attributes={attributes}
          setAttributes={setAttributes}
        />
      </div>
    </>
  );
}
