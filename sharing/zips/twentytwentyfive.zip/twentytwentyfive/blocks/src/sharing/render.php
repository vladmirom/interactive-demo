<?php
/**
 * Render the Sharing Block
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block content.
 * @param WP_Block $block      Block instance.
 */

namespace ValveBlock\Sharing;

// Exit if accessed directly.
defined('ABSPATH') || exit;

// Include the autoloader
require_once __DIR__ . '/lib/autoload.php';

// Get block attributes
$main_color = $attributes['mainColor'] ?? '#000';
$hover_color = $attributes['hoverColor'] ?? '#000';
$enable_hover = $attributes['enableHover'] ?? false;
$selected_sharing_methods = $attributes['selectedSharingMethods'] ?? [];
$gap = $attributes['gap'] ?? '10px';

// Get current page to share.
$server_var = wp_unslash( $_SERVER );
$current_page = ( isset( $server_var['HTTPS'] ) ? 'https' : 'http' ) . "://$server_var[HTTP_HOST]$server_var[REQUEST_URI]";

// Define sharing methods to get correct icons.
$available_sharing_methods = [ 'link', 'facebook', 'linkedin', 'x' ];
$sharing_icons = [];
$sharing_links = [];

// Arrays constructor.
foreach ( $available_sharing_methods as $method_name ) {
	$icon_path = get_template_directory() . '/blocks/src/sharing/icons/' . $method_name . '.svg';
	// If the block is in the project-theme, use the following instead.
	// $icon_path = get_stylesheet_directory() . '/blocks/src/sharing/icons/' . $method_name . '.svg';

	if ( file_exists( $icon_path ) ) {
		// Get the contents of the SVG file
		$sharing_icons[ $method_name ] = file_get_contents( realpath($icon_path) );
	}

	// Sharing links.
	switch ($method_name) {
		case 'facebook':
			$sharing_links[ $method_name ] = SocialMedia\Facebook::get_sharing_link( $current_page );
			break;

		case 'linkedin':
			$sharing_links[ $method_name ] = SocialMedia\LinkedIn::get_sharing_link( $current_page );
			break;

		case 'x':
			$sharing_links[ $method_name ] = SocialMedia\X::get_sharing_link( $current_page );
			break;

		default:
			$sharing_links[ $method_name ] = $current_page; // Copy link
			break;
	}
}

// Generate a unique ID for this block instance
$block_id = 'sharing-' . uniqid();
?>

<?php // Handles hover logic. ?>
<style>
	#<?php echo $block_id; ?> .sharing-icon svg {
		fill: <?php echo $main_color; ?>;
	}

	#<?php echo $block_id; ?> .sharing-icon:hover svg {
		fill: <?php echo $enable_hover ? $hover_color : $main_color; ?>;
	}

	#<?php echo $block_id; ?> .sharing-icon:hover svg .icon-body {
		fill: <?php echo $enable_hover ? $main_color : 'none'; ?>;
	}

	#<?php echo $block_id; ?> .sharing-icons {
		gap: <?php echo $gap . 'px'; ?>;
	}
</style>

<?php // Ouputs the block content. ?>
<?php if ( $selected_sharing_methods && !empty( $selected_sharing_methods ) ): ?>
	<div id="<?php echo $block_id; ?>" class="wp-block-valveblock-sharing" <?php echo get_block_wrapper_attributes(); ?>>
		<div class="sharing-icons">
			<?php foreach( $selected_sharing_methods as $method ):
				$title =  $method[ 'option' ] === 'link' ? __( 'Copy link to the clipboard', 'valve-sharing' ) : __( 'Share on ', 'valve-sharing' ) . ucfirst( $method[ 'option' ] );
				?>

				<a
					href="<?php echo esc_url( $sharing_links[ $method[ 'option' ] ] ); ?>"
					target="_blank"
					title="<?php echo $title; ?>"
					rel="noopener noreferrer"
					class="<?php echo $method[ 'option' ] === 'link' ? 'sharing-icon js-copy-link' : 'sharing-icon';?>"
				>

					<?php echo $sharing_icons[ $method[ 'option' ] ]; ?>

				</a>
				<?php endforeach; ?>
		</div>
</div>
<?php endif; ?>
