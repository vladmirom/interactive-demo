/**
 * WordPress dependencies
 */
import { Icon } from '@wordpress/components';

/**
 * Internal dependencies
 */
import { getIcon } from '../utils/iconUtils';

/**
 * Component for rendering sharing icons in the editor
 *
 * @param {Object} props Component props
 * @return {WPElement} Element to render
 */
const SharingIcons = ({ attributes }) => {
  const { mainColor, hoverColor, enableHover, selectedSharingMethods, gap } = attributes;

  return (
    <div className="sharing-icons" style={{ display: 'flex', gap: `${gap}px` }}>
      {selectedSharingMethods.length > 0 ? (
        selectedSharingMethods.map((link) => (
          <div
            key={link.id}
            className='sharing-icon'
            style={{
              color: mainColor,
              cursor: 'pointer'
            }}
          >
            <Icon
              icon={getIcon(link.option)}
              style={{
                fill: mainColor,
                transition: 'fill 0.4s ease',
              }}
              onMouseEnter={(e) => {
                if (enableHover) {
                  e.currentTarget.style.fill = hoverColor;
                }
              }}
              onMouseLeave={(e) => {
                if (enableHover) {
                  e.currentTarget.style.fill = mainColor;
                }
              }}
            />
          </div>
        ))
      ) : (
        <p>Add sharing options from the sidebar controls</p>
      )}
    </div>
  );
};

export default SharingIcons;
