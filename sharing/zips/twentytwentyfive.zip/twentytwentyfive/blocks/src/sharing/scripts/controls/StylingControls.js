/**
 * WordPress dependencies
 */
import { PanelBody, RangeControl } from '@wordpress/components';

/**
 * Panel controls for styling options
 *
 * @param {Object} props Component props
 * @return {WPElement} Element to render
 */
const StylingControls = ({ attributes, setAttributes }) => {
  const { gap } = attributes;

  return (
    <PanelBody title="Other Styling" initialOpen={true}>
      <RangeControl
        label="Gap Between Icons (px)"
        value={gap}
        onChange={(value) => setAttributes({ gap: value })}
        min={0}
        max={50}
      />
    </PanelBody>
  );
};

export default StylingControls;
