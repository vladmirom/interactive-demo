/**
 * External dependencies
 */
import { v4 as uuidv4 } from 'uuid';

/**
 * WordPress dependencies
 */
import { PanelBody, Button, SelectControl } from '@wordpress/components';
import { useState } from '@wordpress/element';

/**
 * Internal dependencies
 */
import { getSharingOptions } from '../utils/iconUtils';

/**
 * Panel control for selecting and managing sharing methods
 *
 * @param {Object} props Component props
 * @return {WPElement} Element to render
 */
const SharingMethodsControl = ({ attributes, setAttributes }) => {
  const { selectedSharingMethods } = attributes;
  const [selectedOption, setSelectedOption] = useState('');

  const addSocialLink = () => {
    if (!selectedOption) return;

    const newSharingMethods = [
      ...selectedSharingMethods,
      {
        id: uuidv4(),
        option: selectedOption,
        url: '#' // Default URL placeholder
      }
    ];

    setAttributes({
      selectedSharingMethods: newSharingMethods
    });

    // Reset selection after adding
    setSelectedOption('');
  };

  const removeSocialLink = (idToRemove) => {
    const newSharingMethods = selectedSharingMethods.filter(
      (method) => method.id !== idToRemove
    );
    setAttributes({ selectedSharingMethods: newSharingMethods });
  };

  return (
    <PanelBody title="Sharing Method Selection" initialOpen={true}>
      <SelectControl
        label="Sharing Option"
        value={selectedOption || ''}
        options={getSharingOptions()}
        onChange={(value) => setSelectedOption(value)}
      />
      <Button variant="primary" onClick={addSocialLink} style={{ marginTop: '10px' }}>
        Add Sharing Option
      </Button>

      {selectedSharingMethods.map((link) => (
        <div key={link.id} style={{ marginTop: '15px' }}>
          <div className="sharing__option-link">
            <div className="sharing__option-link-label">
              {link.option.charAt(0).toUpperCase() + link.option.slice(1)}
            </div>

            <div className="sharing__option-link-remove">
              <Button
                isDestructive
                onClick={() => removeSocialLink(link.id)}
                style={{ marginTop: '5px' }}
              >
                Remove
              </Button>
            </div>
          </div>
        </div>
      ))}
    </PanelBody>
  );
};

export default SharingMethodsControl;
