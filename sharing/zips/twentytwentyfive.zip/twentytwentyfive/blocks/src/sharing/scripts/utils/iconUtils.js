/**
 * Import SVG components
 */
import { ReactComponent as iconLink } from '../../icons/link.svg';
import { ReactComponent as iconFacebook } from '../../icons/facebook.svg';
import { ReactComponent as iconLinkedin } from '../../icons/linkedin.svg';
import { ReactComponent as iconX } from '../../icons/x.svg';

/**
 * Get the icon component based on the option name
 *
 * @param {string} option The icon option name
 * @return {Component} The SVG icon component
 */
export const getIcon = (option) => {
  switch (option) {
    case 'link':
      return iconLink;
    case 'facebook':
      return iconFacebook;
    case 'linkedin':
      return iconLinkedin;
    case 'x':
      return iconX;
    default:
      return null;
  }
};

/**
 * Get sharing option choices for SelectControl
 *
 * @return {Array} Array of option objects
 */
export const getSharingOptions = () => [
  { label: 'Select an option', value: '' },
  { label: 'Copy link', value: 'link' },
  { label: 'Facebook', value: 'facebook' },
  { label: 'LinkedIn', value: 'linkedin' },
  { label: 'X', value: 'x' },
];
