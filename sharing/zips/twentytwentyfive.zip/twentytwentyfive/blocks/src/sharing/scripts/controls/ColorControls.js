/**
 * WordPress dependencies
 */
import { PanelBody, ToggleControl, ColorPalette } from '@wordpress/components';
import { useSetting } from '@wordpress/block-editor';

/**
 * Panel controls for color settings
 *
 * @param {Object} props Component props
 * @return {WPElement} Element to render
 */
const ColorControls = ({ attributes, setAttributes }) => {
  const { mainColor, hoverColor, enableHover } = attributes;
  const themeColors = useSetting('color.palette');

  return (
    <>
      <PanelBody title="Color Selection" initialOpen={true}>
        <ColorPalette
          label="Main Color"
          colors={themeColors}
          value={mainColor}
          onChange={(color) => setAttributes({ mainColor: color })}
          disableCustomColors={false}
        />
      </PanelBody>

      <PanelBody title="Hover Color" initialOpen={true}>
        <ToggleControl
          label="Enable Hover Color"
          checked={enableHover}
          onChange={(value) => setAttributes({ enableHover: value })}
        />

        {enableHover && (
          <ColorPalette
            label="Hover Color"
            colors={themeColors}
            value={hoverColor}
            onChange={(color) => setAttributes({ hoverColor: color })}
            disableCustomColors={false}
          />
        )}
      </PanelBody>
    </>
  );
};

export default ColorControls;
