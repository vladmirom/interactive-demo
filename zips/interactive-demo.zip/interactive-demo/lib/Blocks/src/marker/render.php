<?php
/**
 * Render the Marker Block
 *
 * Note: this render will go as marker's contnent to the RestAPI and then to modal.
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block content.
 * @param WP_Block $block      Block instance.
 */

 // Perevents empty popups from showing up.
 if ( $content ) {
    echo '<div ' . get_block_wrapper_attributes() . '>';
        echo $content;
    echo '</div>';
 } else {
    return;
 }
