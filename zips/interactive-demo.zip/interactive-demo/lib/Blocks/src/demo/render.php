<?php
/**
 * Render the Navigation Dropdown Block
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block content.
 * @param WP_Block $block      Block instance.
 */

 namespace Valve\InteractiveDemo\DemoBlock;

 use Valve\InteractiveDemo\DemoBlock\Helpers\RestAPI;
 use Valve\InteractiveDemo\DemoBlock\Helpers\FloorData;
 use Valve\InteractiveDemo\DemoBlock\Helpers\MarkerCategories;
 use Valve\InteractiveDemo\DemoBlock\Helpers\MarkerPlacer;

 // Exit if accessed directly.
defined('ABSPATH') || exit;

// Include the autoloader
require_once __DIR__ . '/lib/autoload.php';

// Get selected floors.
$selected_floors = $attributes['selectedFloors'];
$selected_floors_ids = array();

foreach ( $selected_floors as $floor ) {
    array_push( $selected_floors_ids, $floor['floorId'] );
}

$all_floors = RestAPI::get_wp_api_data()['floors']['floor_posts'];

// Filter floors and set them in the correct order.
$filtered_floors = array();

foreach ( $selected_floors_ids as $floor_id ) {
    if ( isset( $all_floors[$floor_id] ) ) {
        array_push( $filtered_floors, $all_floors[$floor_id] );
    }
}

?>

<div <?php echo get_block_wrapper_attributes(); ?>>
    <?php // Top part of demo: description and categories. ?>

    <?php // Note: description always loads the first block description as default. ?>
    <?php if ( !empty( $filtered_floors ) ): ?>
        <div class="demo__floor-description js-floor-desription" data-floor-description-id="<?php echo $filtered_floors[0]['ID']; ?>">
            <?php echo $filtered_floors[0]['title'] ? '<h4 class="demo__floor-description-title">' . $filtered_floors[0]['title'] . '</h4>' : ''; ?>

            <?php echo $filtered_floors[0]['content'] ? $filtered_floors[0]['content'] : ''; ?>
        </div>
    <?php endif; ?>

    <?php // Set marker categories. ?>
    <?php if ( !empty( $filtered_floors ) ): ?>
        <div class="demo__categories js-marker-categories">
            <?php echo MarkerCategories::setMarkerCategories(); ?>
        </div>
    <?php endif; ?>

    <?php // Main part of demo: images. ?>
    <?php if ( !empty( $filtered_floors ) ): ?>
        <div class="demo__floors js-floors" >

            <?php // Set the floor with markers. ?>
            <?php foreach ( $filtered_floors as $floor ): ?>
                <div class="demo__floor js-floor"
                     data-floor-id="<?php echo $floor['ID']; ?>"
                     <?php echo FloorData::getFloorPositionTop( $floor['ID'], $selected_floors ) ? 'data-floor-position-top="' . FloorData::getFloorPositionTop( $floor['ID'], $selected_floors ) . '"' : ''; ?>
                     <?php echo FloorData::getFloorPositionLeft( $floor['ID'], $selected_floors ) ? 'data-floor-position-left="' . FloorData::getFloorPositionLeft( $floor['ID'], $selected_floors ) . '"' : ''; ?>
                     <?php echo FloorData::getFloorWidth( $floor['ID'], $selected_floors ) ? 'data-floor-width="' . FloorData::getFloorWidth( $floor['ID'], $selected_floors ) . '"' : ''; ?>
                     data-is-active="false">

                    <img
                        src="<?php echo esc_url( $floor['image'] ); ?>"
                        alt="<?php echo esc_attr( $floor['title'] ); ?>"
                        class="demo__image"
                        loading="lazy"
                    />

                    <?php // Markers on the floor with their modals. ?>
                    <?php if ( isset( $floor['markers'] ) && !empty( $floor['markers'] ) ): ?>
                        <?php foreach (  $floor['markers'] as $marker_data ): ?>
                            <?php echo MarkerPlacer::placeMarker( $marker_data ); ?>
                        <?php endforeach; ?>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>

        </div>
    <?php endif; ?>

    <?php // Footer part of demo: indicators and sharer. ?>

    <?php // Floor indicators. ?>
    <ul class="demo__indicators js-indicator-list">
        <?php foreach ( $selected_floors_ids as $floor_id ): ?>
            <li class="demo__indicators-item js-indicator" data-indicator-id="<?php echo $floor_id; ?>" data-active="false">
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="6.25" cy="6.5" r="5.625" stroke="white" stroke-width="0.75"/>
                </svg>
            </li>
        <?php endforeach; ?>
    </ul>

    <?php // Sharing button. ?>
    <button type="button" class="demo__sharing js-sharing-button">
        <?php echo __('Share view', 'interactive-demo'); ?>
    </button>
</div>
