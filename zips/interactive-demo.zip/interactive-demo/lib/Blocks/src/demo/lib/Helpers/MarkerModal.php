<?php
/**
 * Class for Demo Block marker modal content.
 *
 * Handles marker modal content and placement.
 *
 * @package InteractiveDemo.
 */

 namespace Valve\InteractiveDemo\DemoBlock\Helpers;

class MarkerModal {
    /**
     * Generates a modal HTML string for a marker with specified data and ID.
     *
     * @param array  $marker_data An associative array containing marker data:
     *                            - 'content' (string): The content to display inside the modal.
     *                            - 'focalPointY' (int|null): The vertical focal point percentage for positioning the modal.
     *                            - 'focalPointX' (int|null): The horizontal focal point percentage for positioning the modal.
     * @param string $ID          The unique identifier for the modal element.
     *
     * @return string The generated HTML string for the marker modal.
     */
    public static function setMarkerModal( array $marker_data, string $ID ): string {
        $marker = '';
        $close_icon = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.2 2.4L16 1.6L14.4 0.00470581L13.6 0.804706L8 6.40471L2.4 0.8L1.6 0L0.0047059 1.6L0.804706 2.4L6.40471 8L0.8 13.6L0 14.4L1.6 15.9953L2.4 15.1953L8 9.59529L13.6 15.2L14.4 16L15.9953 14.4L15.1953 13.6L9.59529 8L15.2 2.4Z" fill="#007B92"/></svg>';

        // Modal render.
        if ( $marker_data['content'] ) {
            $marker .= '<div id="' . $ID . '" class="js-modal demo__marker-modal is-closed" ';
            $marker .= 'data-state="closed" ';
            $marker .= 'style="'; // This style is needed to center the modal right after the marker.
            $marker .= $marker_data['focalPointY'] ? 'top:' . $marker_data['focalPointY'] + 10 . '%; ' : 'top:' . 50 + 10 . '%; '; // Default location of marker is 50%.
            $marker .= $marker_data['focalPointX'] ? 'left:' . $marker_data['focalPointX'] - 40 . '%;' : 'left:' . 50 - 40 . '%; ';  // Default location of marker is 50%.
            $marker .= '"';
            $marker .= '>';
                $marker .= '<button class="js-cross-button demo__marker-modal-close-button">' . $close_icon . '</button>';
                $marker .= $marker_data['content'];
            $marker .= '</div>';
        }

        return $marker;
    }
}

