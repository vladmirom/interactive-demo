<?php
/**
 * Class for Demo Block Rest API.
 *
 * Fetches RestAPI data.
 *
 * @package InteractiveDemo.
 */

 namespace Valve\InteractiveDemo\DemoBlock\Helpers;

class RestAPI {

    /**
     * Retrieves data from the WordPress REST API endpoint.
     *
     * This method sends a GET request to the `/valve/v1/blocks/` endpoint of the
     * current WordPress site and returns the decoded JSON response or an error
     * message if the request fails.
     *
     * @return array The decoded JSON response data or an error message in case of failure.
     *               Possible keys in the returned array:
     *               - 'error': A string containing the error message if an error occurred.
     *               - Other keys as defined by the API response.
     */
    public static function get_wp_api_data() {
        // Set up the request
        $args = array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/json'
            )
        );

        if (function_exists( 'home_url' )) {
            $site_url = home_url();
            $api_endpoint = $site_url . '/wp-json/valve/v1/blocks/';
        }

        // Make the request
        $response = wp_remote_get( $api_endpoint, $args );

        // Check for errors
        if (is_wp_error( $response )) {
            return array( 'error' => $response->get_error_message() );
        }

        // Get the response code
        $response_code = wp_remote_retrieve_response_code( $response );
        if ( $response_code !== 200 ) {
            return array( 'error' => 'API responded with code: ' . $response_code );
        }

        // Get and decode the body
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return array( 'error' => 'JSON decoding error: ' . json_last_error_msg() );
        }

        return $data;
    }
}
