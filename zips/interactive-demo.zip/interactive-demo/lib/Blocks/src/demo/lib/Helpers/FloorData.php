<?php
/**
 * Class for Demo Block floor data.
 *
 * Handles floor data.
 *
 * @package InteractiveDemo.
 */

 namespace Valve\InteractiveDemo\DemoBlock\Helpers;

class FloorData {

    /**
     * Retrieves the width of a specific floor based on its ID.
     *
     * @param int $floorID The ID of the floor whose width is to be retrieved.
     * @param array $floors An array of floor data containing attributes for each floor.
     *
     * @return int|null The width of the floor if found, or null if the floor or attribute does not exist.
     */
    public static function getFloorWidth( int $floorID, array $floors ): ?int {
        return self::getFloorAttribute( 'floorWidth', $floorID, $floors );
    }

    /**
     * Retrieves position top of a specific floor based on its ID.
     *
     * @param int $floorID The ID of the floor whose  position top is to be retrieved.
     * @param array $floors An array of floor data containing attributes for each floor.
     *
     * @return int|null The  position top of the floor if found, or null if the floor or attribute does not exist.
     */
    public static function getFloorPositionTop( int $floorID, array $floors ): ?int {
        return  self::getFloorAttribute( 'positionTop', $floorID, $floors );
    }

    /**
     * Retrieves position left of a specific floor based on its ID.
     *
     * @param int $floorID The ID of the floor whose  position left is to be retrieved.
     * @param array $floors An array of floor data containing attributes for each floor.
     *
     * @return int|null The  position left of the floor if found, or null if the floor or attribute does not exist.
     */
    public static function getFloorPositionLeft( int $floorID, array $floors ): ?int {
        return  self::getFloorAttribute( 'positionLeft', $floorID, $floors );
    }

    /**
     * Retrieves a specific attribute of a floor based on the provided datatype and floor ID.
     *
     * @param string $datatype The type of data to retrieve (e.g., a specific attribute key).
     * @param int $floorID The ID of the floor to search for.
     * @param array $floors An array of floor data, where each floor is represented as an associative array.
     *
     * @return int|null Returns the value of the requested floor attribute if found, or null if not found.
     */
    private static function getFloorAttribute( string $datatype, int $floorID, array $floors ): ?int {
        $floor_data = null;

        foreach ( $floors as $floor ) {
            if ( intval( $floor['floorId'] ) === $floorID ) {
                if ( isset( $floor[ $datatype ] ) && $floor[ $datatype ] ) {
                    $floor_data = $floor[ $datatype ];
                }
            }
        }

        return $floor_data;
    }
}
