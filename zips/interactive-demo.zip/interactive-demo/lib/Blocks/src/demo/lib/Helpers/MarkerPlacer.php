<?php
/**
 * Class for Demo Block marker placer.
 *
 * Places marker to the defined location on the image.
 *
 * @package InteractiveDemo.
 */

 namespace Valve\InteractiveDemo\DemoBlock\Helpers;

 use Valve\InteractiveDemo\DemoBlock\Helpers\MarkerModal;

class MarkerPlacer {

    /**
     * Places marker to the defined position on the image.
     *
     * 1. Places the marker.
     * 2. Adds the modal to the marker.
     *
     * @return string A unique ID string.
     */
    public static function placeMarker( array $marker_data ): string {
        $marker = '';
        $icon = '<svg width="72" height="72" viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
                    <circle class="pulse-ring ring" cx="48" cy="48" r="24" />
                    <circle cx="48" cy="48" r="24" fill="#00667D" />
                    <rect x="47" y="36" width="2" height="24" fill="white" />
                    <rect x="60" y="47" width="2" height="24" transform="rotate(90 60 47)" fill="white" />
                </svg>';
        $marker_id = self::generateUniqueId();

        // Need to convert array of categories into to propper json string.
        $marker_cats = implode(',', array_map(function($val){return sprintf('"%s"', $val);}, $marker_data['categories']));
        $marker_cats_data = ' data-marker-categories=[' . $marker_cats . ']';

        // Icon render.
        $marker .= '<div class="demo__marker-wrap js-marker-button"';
        $marker .= $marker_id ? ' data-marker-id="' . $marker_id . '"' : '';
        $marker .= ' data-marker-state="shown"';
        $marker .= isset( $marker_data['categories'] ) ? $marker_cats_data : '';
        $marker .= ' style="';
        $marker .= $marker_data['focalPointY'] ? 'top:' . $marker_data['focalPointY'] . '%; ' : 'top:50%; '; // Default location of marker is 50%.
        $marker .= $marker_data['focalPointX'] ? 'left:' . $marker_data['focalPointX'] . '%;' : 'left:50%;';  // Default location of marker is 50%.
        $marker .= '">';
            $marker .= $icon;
        $marker .= '</div>';

        // Maker Modal.
        $marker .= MarkerModal::setMarkerModal( $marker_data, $marker_id );

        return $marker;
    }

    /**
     * Generates a unique ID for the marker.
     *
     * This method creates a unique identifier by prefixing 'id_' to a PHP-generated unique ID.
     *
     * @return string A unique ID string.
     */
    private static function generateUniqueId(): string {
        return 'id_' . uniqid();
    }
}
