<?php
/**
 * Class Autoloader
 *
 * Handles automatic class loading for the theme
 */

namespace Valve\InteractiveDemo\DemoBlock;

class Autoloader {
    /**
     * Register the autoloader
     */
    public static function register(): void {
        spl_autoload_register( [new self(), 'autoload'] );
    }

    /**
     * Autoload classes
     *
     * @param string $class_name The fully-qualified class name.
     */
    private function autoload( string $class_name ): void {
        // Project-specific namespace prefix
        $prefix = 'Valve\\InteractiveDemo\\DemoBlock\\';

        // Check if the class uses the namespace prefix
        $len = strlen( $prefix );
        if ( strncmp( $prefix, $class_name, $len ) !== 0 ) {
            return;
        }

        // Get the relative class name
        $relative_class = substr( $class_name, $len );

        // Base plugin directory
        $plugin_dir = dirname( dirname( __FILE__ ) );

        // Map the namespace to the demo/lib directory
        $lib_dir = $plugin_dir . '/lib';

        $file = $lib_dir . '/' . str_replace( '\\', '/', $relative_class ) . '.php';

        // If the file exists, require it
        if ( file_exists( $file ) ) {
            require_once $file;
        } else {
            error_log( "Class file not found: {$file}" );
        }
    }
}

// Register the autoloader
Autoloader::register();
