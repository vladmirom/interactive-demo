<?php
/**
 * Class for Demo Block marker categories.
 *
 * Handles marker modal content and placement.
 *
 * @package InteractiveDemo.
 */

 namespace Valve\InteractiveDemo\DemoBlock\Helpers;

 use Valve\InteractiveDemo\DemoBlock\Helpers\RestAPI;

class MarkerCategories {

    /**
     * Generates and returns a string of HTML markup for marker category checkboxes.
     *
     * This method retrieves marker category data from the WordPress REST API and
     * dynamically creates a list of checkboxes for each category. Each checkbox
     * is checked by default on the first load.
     *
     * @return string The generated HTML string containing the marker category checkboxes.
     */
    public static function setMarkerCategories( ): string {
        $categories = '';

        $categories_data_from_API = RestAPI::get_wp_api_data()['markerCategories'];

        foreach ( $categories_data_from_API as $key => $category ) {
            $categories .= '<div class="checkbox-container">';
                $categories .= '<input type="checkbox" class="js-marker-category visually-hidden"';
                $categories .= ' id="markerCat' . $key . '"';
                $categories .= ' name="markerCat' . $key . '"';
                $categories .= ' value="' . $category['id'] . '"';
                $categories .= ' checked>'; // Checked by default on the first load.

                $categories .= '<label for="markerCat' . $key . '"';
                $categories .= ' class="checkbox-label">';
                $categories .=  $category['name'];
                $categories .= '</label>';
            $categories .= '</div>';
        }

        return $categories;
    }
}
