<?php
/**
 * Class for Floor.
 *
 * Handles Floor custom post type registration.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\PostTypes;

class Floor {
	/**
	 * Class constructor.
	 */
	public function __construct() {

		// Hook up Floor CPT.
		add_action('init', array($this, 'register_cpt'), 100);

	}

	/**
	 * Registers CPT.
	 */
	public function register_cpt() {

		$slug = 'floor';
		$args = $this->define_args();

		register_post_type($slug, $args);
	}

	/**
	 * Defines the arguments for registering a custom post type.
	 *
	 * @return array The arguments array for the custom post type.
	 *
	 */
	public function define_args() {

		$labels = $this->define_labels();

		// Source: https://fontawesome.com/icons/layer-group?f=classic&s=solid
		$icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" fill="#e8eaed"><path d="M264.5 5.2c14.9-6.9 32.1-6.9 47 0l218.6 101c8.5 3.9 13.9 12.4 13.9 21.8s-5.4 17.9-13.9 21.8l-218.6 101c-14.9 6.9-32.1 6.9-47 0L45.9 149.8C37.4 145.8 32 137.3 32 128s5.4-17.9 13.9-21.8L264.5 5.2zM476.9 209.6l53.2 24.6c8.5 3.9 13.9 12.4 13.9 21.8s-5.4 17.9-13.9 21.8l-218.6 101c-14.9 6.9-32.1 6.9-47 0L45.9 277.8C37.4 273.8 32 265.3 32 256s5.4-17.9 13.9-21.8l53.2-24.6 152 70.2c23.4 10.8 50.4 10.8 73.8 0l152-70.2zm-152 198.2l152-70.2 53.2 24.6c8.5 3.9 13.9 12.4 13.9 21.8s-5.4 17.9-13.9 21.8l-218.6 101c-14.9 6.9-32.1 6.9-47 0L45.9 405.8C37.4 401.8 32 393.3 32 384s5.4-17.9 13.9-21.8l53.2-24.6 152 70.2c23.4 10.8 50.4 10.8 73.8 0z"/></svg>';

		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_nav_menus' => true,
			'show_in_rest' => true,
			'query_var' => true,
			'capability_type' => 'post',
			'has_archive' => true,
			'hierarchical' => false,
			'menu_position' => null,
			'menu_icon' => 'data:image/svg+xml;base64,' . base64_encode(string: $icon),
			'supports' => array('title', 'editor', 'thumbnail'),
			'template' => array(
           	 	array('core/post-featured-image')
        	),
        	// 'template_lock' => 'insert'
			// 'rewrite'            => array( 'slug' => 'custom-slug' ), // Custom slug in url
		);

		return $args;
	}

	/**
	 * Define the labels for the custom post type "Floor".
	 *
	 * @return array An associative array of labels for the "Floor" custom post type.
	 */
	public function define_labels() {

		$labels = array(
			'name' => _x('Floors', 'post type general name', 'interactive-demo'),
			'singular_name' => _x('Floor', 'post type singular name', 'interactive-demo'),
			'menu_name' => _x('Floors', 'admin menu', 'interactive-demo'),
			'name_admin_bar' => _x('Floor', 'add new on admin bar', 'interactive-demo'),
			'add_new' => _x('Add New', 'add new item', 'interactive-demo'),
			'add_new_item' => __('Add New Floor', 'interactive-demo'),
			'new_item' => __('New Floor', 'interactive-demo'),
			'edit_item' => __('Edit Floor', 'interactive-demo'),
			'view_item' => __('View Floor', 'interactive-demo'),
			'all_items' => __('All Floors', 'interactive-demo'),
			'search_items' => __('Search Floors', 'interactive-demo'),
			'parent_item_colon' => __('Parent Floors:', 'interactive-demo'),
			'not_found' => __('No Floors found.', 'interactive-demo'),
			'not_found_in_trash' => __('No Floors found in Trash.', 'interactive-demo'),
		);

		return $labels;
	}
}
