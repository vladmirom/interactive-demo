<?php
/**
 * Class for RestAPI registration.
 *
 * Handles RestAPI registration.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\RestAPI;

use Valve\InteractiveDemo\Formatters\Floor;
use Valve\InteractiveDemo\Helpers\Marker;

class RegisterRestAPI {
	/**
	 * Class constructor.
	 */
	public function __construct() {

		add_action( 'rest_api_init', array( $this, 'register_valve_blocks_endpoint' ) );

	}

	/**
	 * Registers a REST API endpoint for valve blocks.
	 *
	 * This function registers a new REST route at 'valve/v1/blocks'
	 * Test link: https://performance-buildings.local/wp-json/valve/v1/blocks/
	 * that supports GET requests.
	 *
	 * @return void
	 */
	public function register_valve_blocks_endpoint() {
		// GET endpoint for retrieving blocks data
		register_rest_route( 'valve/v1', '/blocks', [
			'methods'  => 'GET',
			'callback' => array( $this, 'valve_blocks_data' ),
			'permission_callback' => '__return_true',
		] );

		// POST endpoint for block actions (like adding categories)
		register_rest_route( 'valve/v1', '/blocks', [
			'methods'  => 'POST',
			'callback' => array( $this, 'handle_blocks_actions' ),
			'permission_callback' => function() {
				return current_user_can( 'edit_posts' );
			},
		] );
	}

	/**
	 * Creates an array of data that is accessed by custom blocks.
	 *
	 * @return array An associative array containing the data needed for valve blocks.
	 */
	public function valve_blocks_data() {

		$floors = $this->get_floors();
		$marker_categories = $this->get_marker_categories();

    	return array(
			'floors' => $floors,
			'markerCategories' => $marker_categories,
		);
	}

	/**
	 * Get marker categories.
	 *
	 * @return array Array of marker categories.
	 */
	public function get_marker_categories() {
		// Get categories from options
		$categories = get_option( 'valve_marker_categories', array() );

		// If no categories exist yet, return default set
		if ( empty( $categories ) ) {
			$categories = array(
				array( 'id' => 'infrastructure', 'name' => 'Infrastructure' ),
				array( 'id' => 'building-automation', 'name' => 'Building Automation' ),
				array( 'id' => 'people-circulation', 'name' => 'People Circulation' ),
				array( 'id' => 'vehicle-circulation', 'name' => 'Vehicle Circulation' ),
				array( 'id' => 'amenities', 'name' => 'Amenities' ),
			);

			// Save defaults
			update_option( 'valve_marker_categories', $categories );
		}

		return $categories;
	}

	/**
	 * Get floors.
	 *
	 * @return array Array of floor post type posts.
	 */
	public function get_floors() {
		$floor_data = array(
			'floor_select' => array(),
			'floor_posts' => array(),
		);

		$args = array(
			'post_type'      => 'floor',
			'post_status'    => 'publish',
			'posts_per_page' => -1,  // Get all posts
			'order'          => 'ASC',
		);

		$query = new \WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$floor_data['floor_select'][ get_the_ID() ] = get_the_title();
				$floor_data['floor_posts'][ get_the_ID() ] = array(
					'ID' => get_the_ID(),
					'title' => get_the_title(),
					'image' => get_the_post_thumbnail_url(),
					'content' => Floor::formatFloorDataForAPI( get_the_content() ),
					'markers' => Marker::getMakersFromFloorContent( get_the_content() )
				);
			}

			// Restore original post data
			wp_reset_postdata();
		}

		return $floor_data;
	}


	/**
	 * Handle actions related to blocks via POST requests.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response|\WP_Error Response object on success, or error object on failure.
	 */
	public function handle_blocks_actions( $request ) {
		// Get the action type from the request
		$action = $request->get_param( 'action' );

		// Handle different actions
		switch ( $action ) {
			case 'add_marker_category':
				return $this->add_marker_category( $request );

			// Add more actions here as needed

			default:
				return new \WP_Error(
					'invalid_action',
					'Invalid action specified',
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Add a new marker category.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response|\WP_Error Response object on success, or error object on failure.
	 */
	public function add_marker_category( $request ) {
		$name = $request->get_param( 'name' );

		if ( empty( $name ) ) {
			return new \WP_Error( 'empty_category', 'Category name cannot be empty', array( 'status' => 400 ) );
		}

		// Get existing categories
		$categories = $this->get_marker_categories();

		// Generate ID from name
		$id = sanitize_title( $name );

		// Check if category already exists
		foreach ( $categories as $category ) {
			if ( $category['id'] === $id ) {
				return new \WP_Error( 'duplicate_category', 'Category already exists', array( 'status' => 400 ) );
			}
		}

		// Add new category
		$categories[] = array(
			'id' => $id,
			'name' => $name,
		);

		// Save updated categories
		update_option( 'valve_marker_categories', $categories );

		// Get updated list of categories for response
		$updated_categories = $this->get_marker_categories();

		// Return a successful response with the full data structure
		return rest_ensure_response(
			array(
				'success' => true,
				'category' => array( 'id' => $id, 'name' => $name ),
				'markerCategories' => $updated_categories,
			)
		);
	}
}
