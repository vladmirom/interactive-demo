<?php
/**
 * Class for RegisterValveBlocks.
 *
 * Handles blocks registration.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Helpers;

class RegisterValveBlocks {
	/**
	 * Block manifest.
	 *
	 * @var array
	 */
	private $blocks_manifest;

	/**
	 * Class constructor.
	 */
	public function __construct() {
		// Load blocks manifest.
		$this->load_blocks_manifest();

		// Actions.
		add_action( 'init', array( $this, 'register_blocks' ) );

	}

	/**
	 * Load the blocks manifest file.
	 */
	private function load_blocks_manifest() {
		$manifest_path = dirname( plugin_dir_path( __FILE__ ) ) . '/Blocks/build/blocks-manifest.php';

		if ( file_exists( $manifest_path ) ) {
			$this->blocks_manifest = include $manifest_path;
		} else {
			// Fallback to hardcoded blocks if manifest doesn't exist.
			$this->blocks_manifest = array(
				'marker' => array(),
				'demo' => array(),
			);
		}
	}

	/**
	 * Registers blocks.
	 */
	public function register_blocks() {

		$blocks_dir = dirname( plugin_dir_path( __FILE__ ) ) . '/Blocks/build';

		// If manifest contains a different format than expected, use direct registration.
		if ( empty( $this->blocks_manifest ) || ! is_array( $this->blocks_manifest ) ) {
			register_block_type( $blocks_dir . '/marker' );
			register_block_type( $blocks_dir . '/demo' );
			return;
		}

		// Register blocks from manifest.
		foreach ( $this->blocks_manifest as $block_name => $block_config ) {

			// Ensure the block directory exists
			$block_path = $blocks_dir . '/' . $block_name;

			if ( is_dir( $block_path ) ) {
				register_block_type( $block_path );
			}
		}
	}
}


