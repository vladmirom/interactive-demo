<?php
/**
 * Class for Block helpers.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Helpers;

class Block {
	public static function markerBlockRegistered (): bool {
		$is_registered = false;

		$registry = \WP_Block_Type_Registry::get_instance();
		if ( ! $registry->get_registered( 'valve-blocks/marker' ) ) {
			$is_registered = true;
		}

		return $is_registered;
	}
}
