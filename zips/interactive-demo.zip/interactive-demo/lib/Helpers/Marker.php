<?php
/**
 * Class for Maker helpers.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Helpers;

use Valve\InteractiveDemo\Formatters;

class Marker {
	public static function getMakersFromFloorContent( $content ): array {
		$markers = array();

		$blocks = parse_blocks( $content );

		// Filter for only the valve-blocks/marker blocks
		$marker_blocks = array_filter( $blocks, function( $block ) {
        	return $block['blockName'] === 'valve-blocks/marker';
        });

		if ( !empty( $marker_blocks ) ) {
			foreach ( $marker_blocks as $marker_block ) {
				$formatted_marker = Formatters\Marker::formatMarkerDataForAPI( $marker_block );

				array_push( $markers, $formatted_marker );
			}
		}

		return $markers;
	}
}
