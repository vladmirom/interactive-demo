<?php
/**
 * Class for RegisterValveBlocksCat.
 *
 * Handles Valve block category registration.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Helpers;

class RegisterValveBlocksCat {
	/**
	 * Class constructor.
	 */
	public function __construct() {

		// Filters.
		add_filter( 'block_categories_all', array( $this, 'register_blocks_category' ), 100 );

	}

	/**
	 * Register block categories.
	 *
	 * https://developer.wordpress.org/reference/hooks/block_categories_all
	 *
	 * @return array $block_categories.
	 */
	public function register_blocks_category( $block_categories ) {

		$args = array(
			'slug' => 'valve-blocks',
			'title' => __( 'Valve Blocks', 'interactive-demo' ),
			'icon' => 'valve-blocks',
		);

		array_unshift( $block_categories, $args );

		return $block_categories;
	}
}
