<?php
/**
 * Class for Marker formatter.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Formatters;

class Marker {
	public static function formatMarkerDataForAPI ( $marker ) {
		$formatted_marker = array();

		// Block attributes.
		$attributes = $marker['attrs'];

		if ( $attributes && !empty( $attributes ) ) {
			$formatted_marker['focalPointX'] = isset( $attributes['focalPointX'] ) ?  $attributes['focalPointX'] : '';
			$formatted_marker['focalPointY'] = isset( $attributes['focalPointY'] ) ?  $attributes['focalPointY'] : '';
			$formatted_marker['categories'] = isset( $attributes['selectedCategories'] ) ?  $attributes['selectedCategories'] : array();
		}

		if (function_exists('render_block')) {
			$formatted_marker['content'] = render_block($marker);
		}

		return $formatted_marker;
	}
}
