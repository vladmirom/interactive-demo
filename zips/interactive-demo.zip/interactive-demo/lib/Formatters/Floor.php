<?php
/**
 * Class for Floor formatter.
 *
 * @package InteractiveDemo.
 */

namespace Valve\InteractiveDemo\Formatters;

class Floor {

	/**
	 * Formats floor content data for API consumption by removing specific blocks and trimming whitespace.
	 *
	 * This function processes the given floor content by:
	 * - Removing the featured image block.
	 * - Removing self-closing marker blocks with parameters.
	 * - Removing full marker blocks with content between opening and closing tags.
	 * - Trimming any extra whitespace from the resulting content.
	 *
	 * @param string $floor_content The raw floor content to be formatted.
	 * @return string The formatted floor content, ready for API consumption.
	 */
	public static function formatFloorDataForAPI ( $floor_content ): string {
		$formatted_floor = '';

		// First remove the featured image block
		$filtered_content =  str_replace( '<!-- wp:post-featured-image /-->', '', $floor_content );

		// Pattern 1: Self-closing marker blocks with parameters
		$pattern1 = '/<!-- wp:valve-blocks\/marker\s+\{.*?\}\s+\/-->\s*/s';
		$filtered_content = preg_replace($pattern1, '', $filtered_content);

		// Pattern 2: Full marker blocks with content between opening and closing tags
		$pattern2 = '/<!-- wp:valve-blocks\/marker(?:\s+\{.*?\})?\s*-->(.*?)<!-- \/wp:valve-blocks\/marker -->\s*/s';
		$filtered_content = preg_replace($pattern2, '', $filtered_content);

		// Trim any extra whitespace
		$filtered_content = trim($filtered_content);

		$formatted_floor = $filtered_content;

		return $formatted_floor;
	}
}
