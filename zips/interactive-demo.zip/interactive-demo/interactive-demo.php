<?php
/**
 * Plugin Name:       Interactive Demo
 * Description:       Custom plugin adding blocks to add Interactive Demo feature for Performance Buildings project.
 * Author: 			  Valve Branding Oy
 * Author URI: 		  https://valve.fi/
 * Version:           1.0.0
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       interactive-demo
 * Domain Path: 	  /assets/languages/
 *
 * @author    		  Volodymyr Melnychenko
 * @copyright 		  Copyright (c) 2025
 * @package           InteractiveDemo
 */

namespace Valve\InteractiveDemo;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

// Include autoloader
require_once plugin_dir_path(__FILE__) . 'lib/autoload.php';

// PostTypes.
use Valve\InteractiveDemo\PostTypes\Floor;

// RestAPI.
use Valve\InteractiveDemo\RestAPI\RegisterRestAPI;

// Taxonomies. No taxonomies assigned to Marker.
// use Valve\InteractiveDemo\Taxonomies\MarkerType;

// Helpers.
use Valve\InteractiveDemo\Helpers\RegisterValveBlocks;
use Valve\InteractiveDemo\Helpers\RegisterValveBlocksCat;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}


final class InteractiveDemo {
	/**
	 * Floor Post type instance.
	 *
	 * @var Floor
	 */
	private $floor;

	/**
	 * Register Valve Blocks Category.
	 *
	 * @var RegisterValveBlocksCat
	 */
	private $register_valve_cat;

    /**
	 * Register Valve Blocks.
	 *
	 * @var RegisterRestAPI
	 */
	private $register_valve_restapi;

	/**
	 * Register Valve Blocks.
	 *
	 * @var RegisterValveBlocks
	 */
	private $register_valve_blocks;

	/**
	 * Main class constructor
	 *
	 */
	public function __construct() {

		// Class instances.
		$this->floor = new Floor();
		$this->register_valve_cat = new RegisterValveBlocksCat();
		$this->register_valve_restapi = new RegisterRestAPI();
		$this->register_valve_blocks = new RegisterValveBlocks();

	}
}

new InteractiveDemo();
